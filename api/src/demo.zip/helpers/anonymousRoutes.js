// Add all the anonymous routes here.
AnonymousRoutes = [
    '/auth/login',
];

module.exports = AnonymousRoutes;