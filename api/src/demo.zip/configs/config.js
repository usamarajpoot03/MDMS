const config = {
    secret : 'secret_here'
};

module.exports = config;